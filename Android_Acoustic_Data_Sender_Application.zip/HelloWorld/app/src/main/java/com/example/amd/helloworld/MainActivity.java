package com.example.amd.helloworld;

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    String                  userText;
    AudioTrack              track;
    HashMap<String, String> freqMap;

    private void playSound(double frequency, int duration) {

        int mBufferSize = AudioTrack.getMinBufferSize(44100,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_8BIT);

        AudioTrack mAudioTrack = new AudioTrack(AudioManager.STREAM_MUSIC, 44100,
                AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                mBufferSize, AudioTrack.MODE_STREAM);

        double[] mSound = new double[4410];
        short[] mBuffer = new short[duration];
        for (int i = 0; i < mSound.length; i++) {
            mSound[i] = Math.sin((2.0*Math.PI * i/(44100/frequency)));
            mBuffer[i] = (short) (mSound[i]*Short.MAX_VALUE);
        }

        mAudioTrack.setStereoVolume(AudioTrack.getMaxVolume(), AudioTrack.getMaxVolume());
        mAudioTrack.play();

        mAudioTrack.write(mBuffer, 0, mSound.length);
        mAudioTrack.stop();
        mAudioTrack.release();
    }

    private AudioTrack generateTone(double freqHz, int durationMs) {
        int count = (int)(44100.0 * 2.0 * (durationMs / 1000.0)) & ~1;
        short[] samples = new short[count];
        for(int i = 0; i < count; i += 2){
            short sample = (short)(Math.sin(2 * Math.PI * i / (44100.0 / freqHz)) * 0x7FFF);
            samples[i + 0] = sample;
            samples[i + 1] = sample;
        }
        AudioTrack track = new AudioTrack(AudioManager.STREAM_MUSIC,
                                44100,
                                AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT,
                                count * (Short.SIZE / 8), AudioTrack.MODE_STATIC);
        track.write(samples, 0, count);
        return track;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        freqMap = new HashMap<String, String>();
        freqMap.put("a", "200");
        freqMap.put("b", "240");
        freqMap.put("c", "280");
        freqMap.put("d", "320");
        freqMap.put("e", "360");
        freqMap.put("f", "400");
        freqMap.put("g", "440");
        freqMap.put("h", "480");
        freqMap.put("i", "520");
        freqMap.put("j", "560");
        freqMap.put("k", "600");
        freqMap.put("l", "640");
        freqMap.put("m", "680");
        freqMap.put("n", "720");
        freqMap.put("o", "760");
        freqMap.put("p", "800");
        freqMap.put("q", "840");
        freqMap.put("r", "880");
        freqMap.put("s", "920");
        freqMap.put("t", "960");
        freqMap.put("u", "1000");
        freqMap.put("v", "1040");
        freqMap.put("w", "1080");
        freqMap.put("x", "1120");
        freqMap.put("y", "1160");
        freqMap.put("z", "1200");

        Button btn = (Button) findViewById(R.id.button1);
        final EditText edtText = (EditText) findViewById(R.id.editText1);
        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                userText = edtText.getText().toString();
                for (final char c: userText.toCharArray()) {
                    Log.d("AMD", freqMap.get(String.valueOf(c)));

                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    track = generateTone(Double.parseDouble(freqMap.get(String.valueOf(c))), 1000);
                    track.play();
                }
            }
        });
    }
}
